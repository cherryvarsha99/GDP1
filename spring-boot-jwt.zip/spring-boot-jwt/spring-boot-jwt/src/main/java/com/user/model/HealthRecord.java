package com.user.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "health_record")
public class HealthRecord{

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Integer id;
	
	@Column(name = "email")
	private String email;

	@Column(name = "tobacco")
	private String tobacco;

	@Column(name = "conditionsapply")
	private String conditionsapply;

	@Column(name = "consumealcohol")
	private String consumealcohol;
	
	@Column(name = "experiencing")
	private String experiencing;
	
	@Column(name = "fullname")
	private String fullname;
	
	@Column(name = "gender")
	private String gender;
	
	
	@Column(name = "illegaldrugs")
	private String illegaldrugs;
	
	@Column(name = "lactating")
	private String lactating;
	
	
	@Column(name = "phonumber")
	private String phonumber;
	
	@Column(name = "pregnant")
	private String pregnant;
	
	@Column(name = "takingmedication")
	private String takingmedication;
	
	@Column(name = "testedPositive")
	private String testedPositive;
	
	@Column(name = "age")
	private Integer age;
	
	@Column(name = "covidpositive")
	private String covidpositive;
	
	@Column(name = "sick")
	private String sick;
	
	@Column(name = "beforevaccine")
	private String beforevaccine;
	
	@Column(name = "symptomscovid")
	private String symptomscovid;
	
	@Column(name = "polysorbate")
	private String polysorbate;
	
	@Column(name = "vaccinedose")
	private String vaccinedose;
	
	@Column(name = "drugsortherapies")
	private String drugsortherapies;

	@Column(name = "bloodthinner")
	private String bloodthinner;


	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getTobacco() {
		return tobacco;
	}

	public void setTobacco(String tobacco) {
		this.tobacco = tobacco;
	}

	public String getConditionsapply() {
		return conditionsapply;
	}

	public void setConditionsapply(String conditionsapply) {
		this.conditionsapply = conditionsapply;
	}

	public String getConsumealcohol() {
		return consumealcohol;
	}

	public void setConsumealcohol(String consumealcohol) {
		this.consumealcohol = consumealcohol;
	}

	public String getExperiencing() {
		return experiencing;
	}

	public void setExperiencing(String experiencing) {
		this.experiencing = experiencing;
	}

	public String getFullname() {
		return fullname;
	}

	public void setFullname(String fullname) {
		this.fullname = fullname;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public String getIllegaldrugs() {
		return illegaldrugs;
	}

	public void setIllegaldrugs(String illegaldrugs) {
		this.illegaldrugs = illegaldrugs;
	}

	public String getLactating() {
		return lactating;
	}

	public void setLactating(String lactating) {
		this.lactating = lactating;
	}

	public String getPhonumber() {
		return phonumber;
	}

	public void setPhonumber(String phonumber) {
		this.phonumber = phonumber;
	}

	public String getPregnant() {
		return pregnant;
	}

	public void setPregnant(String pregnant) {
		this.pregnant = pregnant;
	}

	public String getTakingmedication() {
		return takingmedication;
	}

	public void setTakingmedication(String takingmedication) {
		this.takingmedication = takingmedication;
	}

	public String getTestedPositive() {
		return testedPositive;
	}

	public void setTestedPositive(String testedPositive) {
		this.testedPositive = testedPositive;
	}

	
	
	public Integer getAge() {
		return age;
	}

	public void setAge(Integer age) {
		this.age = age;
	}

	public String getCovidpositive() {
		return covidpositive;
	}

	public void setCovidpositive(String covidpositive) {
		this.covidpositive = covidpositive;
	}

	public String getSick() {
		return sick;
	}

	public void setSick(String sick) {
		this.sick = sick;
	}

	public String getBeforevaccine() {
		return beforevaccine;
	}

	public void setBeforevaccine(String beforevaccine) {
		this.beforevaccine = beforevaccine;
	}

	public String getSymptomscovid() {
		return symptomscovid;
	}

	public void setSymptomscovid(String symptomscovid) {
		this.symptomscovid = symptomscovid;
	}

	public String getPolysorbate() {
		return polysorbate;
	}

	public void setPolysorbate(String polysorbate) {
		this.polysorbate = polysorbate;
	}

	public String getVaccinedose() {
		return vaccinedose;
	}

	public void setVaccinedose(String vaccinedose) {
		this.vaccinedose = vaccinedose;
	}

	public String getDrugsortherapies() {
		return drugsortherapies;
	}

	public void setDrugsortherapies(String drugsortherapies) {
		this.drugsortherapies = drugsortherapies;
	}

	public String getBloodthinner() {
		return bloodthinner;
	}

	public void setBloodthinner(String bloodthinner) {
		this.bloodthinner = bloodthinner;
	}
	
	
	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	@Override
	public String toString() {
		return "HealthRecord [id=" + id + ", tobacco=" + tobacco + ", conditionsapply=" + conditionsapply
				+ ", consumealcohol=" + consumealcohol + ", experiencing=" + experiencing + ", fullname=" + fullname
				+ ", gender=" + gender + ", illegaldrugs=" + illegaldrugs + ", lactating=" + lactating + ", phonumber="
				+ phonumber + ", pregnant=" + pregnant + ", takingmedication=" + takingmedication + ", testedPositive="
				+ testedPositive + ", age=" + age + ", covidpositive=" + covidpositive + ", sick=" + sick
				+ ", beforevaccine=" + beforevaccine + ", symptomscovid=" + symptomscovid + ", polysorbate="
				+ polysorbate + ", vaccinedose=" + vaccinedose + ", drugsortherapies=" + drugsortherapies
				+ ", bloodthinner=" + bloodthinner + "]";
	}

	

	
	
}
