package com.user.dto;



import com.fasterxml.jackson.annotation.JsonRawValue;
import com.fasterxml.jackson.databind.JsonNode;

public class HealthRecordDto  {

	private Integer id;

	private String tobacco;
	
	private String email;


	private String consumealcohol;
	private Object conditionsapply;
	
	private Object experiencing;
	
	private String fullname;
	
	private String gender;
	
	
	private String illegaldrugs;
	
	private String lactating;
	
	
	private String phonumber;
	
	private String pregnant;
	
	private String takingmedication;
	
	private String testedPositive;
	
	private Integer age;
	
	private String covidpositive;
	
	private String sick;
	
	private String beforevaccine;
	
	private String symptomscovid;
	
	private String polysorbate;
	
	private String vaccinedose;
	
	private String drugsortherapies;

	private String bloodthinner;
	

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getTobacco() {
		return tobacco;
	}

	public void setTobacco(String tobacco) {
		this.tobacco = tobacco;
	}

	public String getConditionsapply() {
		return conditionsapply ==null ? null: conditionsapply.toString();
	}

	@JsonRawValue
	public void setConditionsapply(JsonNode conditionsapply) {
		this.conditionsapply = conditionsapply;
	}

	public String getConsumealcohol() {
		return consumealcohol;
	}

	public void setConsumealcohol(String consumealcohol) {
		this.consumealcohol = consumealcohol;
	}

	public String getExperiencing() {
		return experiencing ==null ? null: experiencing.toString();
	}

	@JsonRawValue
	public void setExperiencing(JsonNode experiencing) {
		this.experiencing = experiencing;
	}

	public String getFullname() {
		return fullname;
	}

	public void setFullname(String fullname) {
		this.fullname = fullname;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public String getIllegaldrugs() {
		return illegaldrugs;
	}

	public void setIllegaldrugs(String illegaldrugs) {
		this.illegaldrugs = illegaldrugs;
	}

	public String getLactating() {
		return lactating;
	}

	public void setLactating(String lactating) {
		this.lactating = lactating;
	}

	public String getPhonumber() {
		return phonumber;
	}

	public void setPhonumber(String phonumber) {
		this.phonumber = phonumber;
	}

	public String getPregnant() {
		return pregnant;
	}

	public void setPregnant(String pregnant) {
		this.pregnant = pregnant;
	}

	public String getTakingmedication() {
		return takingmedication;
	}

	public void setTakingmedication(String takingmedication) {
		this.takingmedication = takingmedication;
	}

	public String getTestedPositive() {
		return testedPositive;
	}

	public void setTestedPositive(String testedPositive) {
		this.testedPositive = testedPositive;
	}

	public Integer getAge() {
		return age;
	}

	public void setAge(Integer age) {
		this.age = age;
	}

	public String getCovidpositive() {
		return covidpositive;
	}

	public void setCovidpositive(String covidpositive) {
		this.covidpositive = covidpositive;
	}

	public String getSick() {
		return sick;
	}

	public void setSick(String sick) {
		this.sick = sick;
	}

	public String getBeforevaccine() {
		return beforevaccine;
	}

	public void setBeforevaccine(String beforevaccine) {
		this.beforevaccine = beforevaccine;
	}

	public String getSymptomscovid() {
		return symptomscovid;
	}

	public void setSymptomscovid(String symptomscovid) {
		this.symptomscovid = symptomscovid;
	}

	public String getPolysorbate() {
		return polysorbate;
	}

	public void setPolysorbate(String polysorbate) {
		this.polysorbate = polysorbate;
	}

	public String getVaccinedose() {
		return vaccinedose;
	}

	public void setVaccinedose(String vaccinedose) {
		this.vaccinedose = vaccinedose;
	}

	public String getDrugsortherapies() {
		return drugsortherapies;
	}

	public void setDrugsortherapies(String drugsortherapies) {
		this.drugsortherapies = drugsortherapies;
	}

	public String getBloodthinner() {
		return bloodthinner;
	}

	public void setBloodthinner(String bloodthinner) {
		this.bloodthinner = bloodthinner;
	}

	

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	@Override
	public String toString() {
		return "HealthRecordDto [id=" + id + ", tobacco=" + tobacco + ", conditionsapply=" + conditionsapply
				+ ", consumealcohol=" + consumealcohol + ", experiencing=" + experiencing + ", fullname=" + fullname
				+ ", gender=" + gender + ", illegaldrugs=" + illegaldrugs + ", lactating=" + lactating + ", phonumber="
				+ phonumber + ", pregnant=" + pregnant + ", takingmedication=" + takingmedication + ", testedPositive="
				+ testedPositive + ", age=" + age + ", covidpositive=" + covidpositive + ", sick=" + sick
				+ ", beforevaccine=" + beforevaccine + ", symptomscovid=" + symptomscovid + ", polysorbate="
				+ polysorbate + ", vaccinedose=" + vaccinedose + ", drugsortherapies=" + drugsortherapies
				+ ", bloodthinner=" + bloodthinner + "]";
	}

}
