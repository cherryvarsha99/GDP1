package com.user.dto;

import java.util.List;

import com.user.model.Role;

import io.swagger.annotations.ApiModelProperty;

public class UserDataDTO {
  
  @ApiModelProperty(position = 0)
  private String email;
  @ApiModelProperty(position = 1)
  private String password;
  @ApiModelProperty(position = 2)
  List<Role> roles;
  
  private String firstName;
  
  private String lastName;
  
  private String phonumber;


  public String getEmail() {
    return email;
  }

  public void setEmail(String email) {
    this.email = email;
  }

  public String getPassword() {
    return password;
  }

  public void setPassword(String password) {
    this.password = password;
  }

  public List<Role> getRoles() {
    return roles;
  }

  public void setRoles(List<Role> roles) {
    this.roles = roles;
  }




public String getFirstName() {
	return firstName;
}

public void setFirstName(String firstName) {
	this.firstName = firstName;
}

public String getLastName() {
	return lastName;
}

public void setLastName(String lastName) {
	this.lastName = lastName;
}

public String getPhonumber() {
	return phonumber;
}

public void setPhonumber(String phonumber) {
	this.phonumber = phonumber;
}
  
  

}
