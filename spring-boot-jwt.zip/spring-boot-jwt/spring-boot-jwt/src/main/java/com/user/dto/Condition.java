package com.user.dto;

import java.util.List;

public class Condition {

	
	List<String> conditions;

	public List<String> getConditions() {
		return conditions;
	}

	public void setConditions(List<String> conditions) {
		this.conditions = conditions;
	}
	
	
	
}
