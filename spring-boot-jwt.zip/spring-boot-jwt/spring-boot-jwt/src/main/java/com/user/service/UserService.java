package com.user.service;

import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import com.user.dto.HealthRecordDto;
import com.user.dto.UserResponseDTO;
import com.user.exception.CustomException;
import com.user.model.HealthRecord;
import com.user.model.User;
import com.user.repository.HealthRecordRepository;
import com.user.repository.UserRepository;
import com.user.security.JwtTokenProvider;

@Service
public class UserService {

  @Autowired
  private UserRepository userRepository;

  @Autowired
  private PasswordEncoder passwordEncoder;

  @Autowired
  private JwtTokenProvider jwtTokenProvider;
  
  @Autowired
  private HealthRecordRepository healthRecordRepository;

  @Autowired
  private AuthenticationManager authenticationManager;
  
  @Autowired
  private ModelMapper modelMapper;

  public UserResponseDTO signin(String email, String password) {
    try {
      authenticationManager.authenticate(new UsernamePasswordAuthenticationToken(email, password));
      
      User user=userRepository.findByEmail(email);
      
      String token= jwtTokenProvider.createToken(email, user.getRoles());
    
      UserResponseDTO userRes=modelMapper.map(user, UserResponseDTO.class);
      
      userRes.setJwtToken(token);
       
       return userRes;
    } catch (AuthenticationException e) {
      throw new CustomException("Invalid username/password supplied", HttpStatus.UNPROCESSABLE_ENTITY);
    }
  }

  public UserResponseDTO signup(User user) {
    if (!userRepository.existsByEmail(user.getEmail())) {
      user.setPassword(passwordEncoder.encode(user.getPassword()));
      User userSaved=userRepository.save(user);
      
      
      String token= jwtTokenProvider.createToken(user.getEmail(), user.getRoles());

      UserResponseDTO userRes=modelMapper.map(user, UserResponseDTO.class);
      userRes.setFirstname(user.getFirstname());
      userRes.setLastname(user.getLastname());
      
      
      userRes.setJwtToken(token);

      
      return userRes;
    } else {
      throw new CustomException("Username is already in use", HttpStatus.UNPROCESSABLE_ENTITY);
    }
  }

  public void delete(String username) {
    userRepository.deleteByEmail(username);
  }

  public User search(String username) {
    User user = userRepository.findByEmail(username);
    if (user == null) {
      throw new CustomException("The user doesn't exist", HttpStatus.NOT_FOUND);
    }
    return user;
  }

  public User whoami(HttpServletRequest req) {
    return userRepository.findByEmail(jwtTokenProvider.getUsername(jwtTokenProvider.resolveToken(req)));
  }

  public String refresh(String username) {
    return jwtTokenProvider.createToken(username, userRepository.findByEmail(username).getRoles());
  }

	public HealthRecord healthRecordSevice(HttpServletRequest req, HealthRecordDto healthRecordDto) {
		HealthRecord healthRecord=null;
		HealthRecord healthRecordFind = healthRecordRepository.findByEmail(healthRecordDto.getEmail());
		jwtTokenProvider.getUsername(jwtTokenProvider.resolveToken(req));
		 healthRecord= modelMapper.map(healthRecordDto, HealthRecord.class);
		if(healthRecordFind!=null) {
			healthRecord.setId(healthRecordFind.getId());
		}
		return healthRecordRepository.save(healthRecord);
	}

	public HealthRecord gethealthRecordSevice(String email) {
		return healthRecordRepository.findByEmail(email);
	}


}
