/*
SQLyog Ultimate v11.11 (64 bit)
MySQL - 5.7.33-log : Database - user_db
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
CREATE DATABASE /*!32312 IF NOT EXISTS*/`user_db` /*!40100 DEFAULT CHARACTER SET latin1 */;

USE `user_db`;

/*Table structure for table `health_record` */

DROP TABLE IF EXISTS `health_record`;

CREATE TABLE `health_record` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `email` varchar(255) NOT NULL,
  `conditionsapply` varchar(255) DEFAULT NULL,
  `consumealcohol` varchar(255) DEFAULT NULL,
  `experiencing` varchar(255) DEFAULT NULL,
  `fullname` varchar(255) DEFAULT NULL,
  `gender` varchar(255) DEFAULT NULL,
  `illegaldrugs` varchar(255) DEFAULT NULL,
  `lactating` varchar(255) DEFAULT NULL,
  `phonumber` varchar(255) DEFAULT NULL,
  `pregnant` varchar(255) DEFAULT NULL,
  `takingmedication` varchar(255) DEFAULT NULL,
  `tested_positive` varchar(255) DEFAULT NULL,
  `tobacco` varchar(255) DEFAULT NULL,
  `age` int(11) DEFAULT NULL,
  `covidpositive` varchar(255) DEFAULT NULL,
  `sick` varchar(255) DEFAULT NULL,
  `beforevaccine` varchar(255) DEFAULT NULL,
  `symptomscovid` varchar(255) DEFAULT NULL,
  `polysorbate` varchar(255) DEFAULT NULL,
  `vaccinedose` varchar(255) DEFAULT NULL,
  `drugsortherapies` varchar(255) DEFAULT NULL,
  `bloodthinner` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=latin1;

/*Data for the table `health_record` */

insert  into `health_record`(`id`,`email`,`conditionsapply`,`consumealcohol`,`experiencing`,`fullname`,`gender`,`illegaldrugs`,`lactating`,`phonumber`,`pregnant`,`takingmedication`,`tested_positive`,`tobacco`,`age`,`covidpositive`,`sick`,`beforevaccine`,`symptomscovid`,`polysorbate`,`vaccinedose`,`drugsortherapies`,`bloodthinner`) values (7,'smolleti@gmail.com','[{\"name\":\"Asthma\",\"selected\":true},{\"name\":\"Cancer\",\"selected\":true},{\"name\":\"Cardiac Disease\",\"selected\":false},{\"name\":\"Diabetic\",\"selected\":true},{\"name\":\"Blood Pressure\",\"selected\":true}]','Never','[]','hemanth','Male','No','No','7868796897','No','No',NULL,'No',26,'No','No','No','No','No','No','No','No'),(8,'smolleti1@gmail.com','[\"Blood Pressure\"]','Never','[\"Pshychiatiric\"]','hemanth','Male','No','No','7868796897','No','No',NULL,'No',26,'No','No','No','No','No','No','No','No');

/*Table structure for table `user` */

DROP TABLE IF EXISTS `user`;

CREATE TABLE `user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `email` varchar(255) NOT NULL,
  `firstname` varchar(255) DEFAULT NULL,
  `lastname` varchar(255) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `phonumber` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UK_ob8kqyqqgmefl0aco34akdtpe_em` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=latin1;

/*Data for the table `user` */

insert  into `user`(`id`,`email`,`firstname`,`lastname`,`password`,`phonumber`) values (1,'admin@email.com','admin','admin','$2a$12$y4VI.63nHXQ4JZ1jn.m9V.ja9Lnv0axckQslZ1o5du2iTF.lNIfx.','99999999999'),(2,'client@email.com','client','client','$2a$12$UGff.EnKl77nLxPsnXc/I.tTyUAiZrMPSTOhFfSU/j5Es9gPbqxMa','8888888888'),(3,'hemanth@gmail.com','hemanth','sativada','$2a$12$XvMs7MeIz6c3f01Rz.wgq.h2.E2mzrpeFRdIe9vG0YL5lLLNfCNY2','964-051-6462'),(4,'molleti@gmail.com',NULL,NULL,'$2a$12$VvMIuqnsbbiQ327NzoTaUuy.F6aZ6eY/6GESqg795kgnWhCXzS8xu','814-372-6164'),(5,'smolleti@gmail.com','suresh','molleti','$2a$12$pANqYigsPrsepr6bPSs1KuGGqnSNydb5VGD7TJ8/LDqjlOgAQsUny','8188888888'),(6,'sm@gmail.com','suresh','molleti','$2a$12$FTzW7rD9Ng8qJxVwTIAICe7MJ50W2Yz1rIPHnScnc9ADQhWUdVuii','8188888888'),(7,'sm1@gmail.com','suresh','molleti','$2a$12$VstAa72blZCKCsfKXC.anOI79nDWS9ic0j1DUUSHDcF2SlcyQCJDi','8188888888');

/*Table structure for table `user_roles` */

DROP TABLE IF EXISTS `user_roles`;

CREATE TABLE `user_roles` (
  `user_id` int(11) NOT NULL,
  `roles` int(11) DEFAULT NULL,
  KEY `FK55itppkw3i07do3h7qoclqd4k_uu` (`user_id`),
  CONSTRAINT `FK55itppkw3i07do3h7qoclqd4k_rr` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `user_roles` */

insert  into `user_roles`(`user_id`,`roles`) values (1,0),(2,1),(3,1),(4,1),(5,0),(6,0),(7,1);

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
