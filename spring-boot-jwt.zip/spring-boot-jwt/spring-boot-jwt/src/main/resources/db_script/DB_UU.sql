CREATE TABLE `health_record` (
  `id` INT(11) NOT NULL AUTO_INCREMENT,
  `conditionsapply` VARCHAR(255) DEFAULT NULL,
  `consumealcohol` VARCHAR(255) DEFAULT NULL,
  `experiencing` VARCHAR(255) DEFAULT NULL,
  `fullname` VARCHAR(255) DEFAULT NULL,
  `gender` VARCHAR(255) DEFAULT NULL,
  `illegaldrugs` VARCHAR(255) DEFAULT NULL,
  `lactating` VARCHAR(255) DEFAULT NULL,
  `phonumber` VARCHAR(255) DEFAULT NULL,
  `pregnant` VARCHAR(255) DEFAULT NULL,
  `takingmedication` VARCHAR(255) DEFAULT NULL,
  `tested_positive` VARCHAR(255) DEFAULT NULL,
  `tobacco` VARCHAR(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
)

CREATE TABLE `user` (
  `id` INT(11) NOT NULL AUTO_INCREMENT,
  `email` VARCHAR(255) NOT NULL,
  `firstname` VARCHAR(255) DEFAULT NULL,
  `lastname` VARCHAR(255) DEFAULT NULL,
  `password` VARCHAR(255) DEFAULT NULL,
  `phonumber` VARCHAR(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UK_ob8kqyqqgmefl0aco34akdtpe_em` (`email`)
)

CREATE TABLE `user_roles` (
  `user_id` INT(11) NOT NULL,
  `roles` INT(11) DEFAULT NULL,
  KEY `FK55itppkw3i07do3h7qoclqd4k_uu` (`user_id`),
  CONSTRAINT `FK55itppkw3i07do3h7qoclqd4k_rr` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`)
)

